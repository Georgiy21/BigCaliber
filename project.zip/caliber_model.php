<?php
// connect to MySQL DB
$conn = mysqli_connect('localhost', 'gvoropayev', 'fifa21rus', 'C354_gvoropayev');

if(!isset($_SERVER['HTTPS'])){
    $url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('Location: ' . $url);
    exit;
}

function insert_new_user($username, $password, $fname, $lname, $email, $dr_license)
{
    global $conn;
    //$hashed_password = hash(SHA256, $password);

    if (does_exist($username))
        return false;
    else {

        $sql = "insert into Customers values (NULL, '$username', '$password', '$fname', '$lname', '$email', '$dr_license')";
        $result = mysqli_query($conn, $sql);
        return $result;
    }
}

function is_valid($username, $password)
{
    global $conn;

    //$algorithm = SHA256;
    //$hashed_password = hash($algorithm, $password);

    $sql = "select * from Customers where (Username = '$username' and Password = '$password')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
        return true;
    else
        return false;
}

function does_exist($username)
{
    global $conn;

    $sql = "select * from Customers where (Username = '$username')";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0)
        return true;
    else
        return false;
}

function reset_password($username, $new_password)
{
    global $conn;
    //$hashed_password = hash(SHA256, $new_password);

    $sql = "update Customers set password = '$new_password' where username = '$username'";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function buy_rifle($fname, $lname, $dr_license, $address, $city, $rifle)
{
  global $conn;
  $sql = "insert into Buyers values ('$fname', '$lname', '$dr_license', '$address', '$city', '$rifle')";
  $result = mysqli_query($conn, $sql);
  return $result;
}

function sell_rifle($fname, $lname, $dr_license, $address, $city, $make, $model, $caliber, $sin, $comment)
{
  global $conn;
  $sql = "insert into Sellers values ('$fname', '$lname', '$dr_license', '$address', '$city', '$make', '$model', '$caliber', '$sin', '$comment')";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0)
      return $result;
  else {
      echo "Table is empty";
      return false;
  }
}

function unsubscribe($username)
{
  global $conn;

  $sql = "delete from Customers where username = '$username'";
  $result = mysqli_query($conn, $sql);
  return $result;

}
?>
