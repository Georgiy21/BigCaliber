<!DOCTYPE html>

<?php
  session_start();
?>

<html>
<head>
    <title>Big Caliber</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
        #back{
          background:url('deer-background.jpg') no-repeat center center fixed;

          display: table;
          height:100%;
          position: relative;
          width: 100%;
          background-size: cover;
        }
        #list{
          background-image: url('light-wood.jpg');
        }
        img{
          max-width: 100%;
        }
        #hamburger{
          position: fixed;
          top: 0;
          right: 30px;
        }
        #hamburger li, #hamburger ul {
            list-style: none;
            padding: 0;
            background-color: Gray;
            cursor:pointer;
        }
        #hamburger ul {
            border:1px solid black;
        }
        #hamburger > li {
            position: relative;
        }
        #hamburger > li > ul {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
        }
        #hamburger > li > ul > li { padding: 5px; }
        #hamburger li:hover {
            background-color: #eee;
        }
        #hamburger > li:hover > ul {
            display: block;
        }
    </style>

    <script>
        window.addEventListener('load', function() {
            document.getElementById('startpage').addEventListener('click', open_startpage);
            document.getElementById('sell').addEventListener('click', open_sell);
            document.getElementById('forum').addEventListener('click', open_forum);
            document.getElementById('menu-signout').addEventListener('click', signout);

            document.getElementById('buy-m700').addEventListener('click', open_m700);
            document.getElementById('buy-sako85').addEventListener('click', open_sako85);
            document.getElementById('buy-smasher').addEventListener('click', open_smasher);
            function open_m700(){
              window.open('m700.php', '_self');
            }
            function open_sako85(){
              window.open('sako85.php', '_self');
            }
            function open_smasher(){
              window.open('smasher.php', '_self');
            }
        });

        function open_sell(){
            window.open("caliber_sellpage.php", "_self");
        }
        function open_forum(){
            window.open("caliber_forumpage.php", "_self");
        }
        function open_startpage(){
            window.open("caliber_startpage.php", "_self");
        }
        function signout() {
            document.getElementById('form-signout').submit();
        }
    </script>
</head>
<body>
  <div class="containerTab">
    <h1 style='text-align:center; padding-top: 10px'>Big Caliber</h1>
    <h3 style='text-align:center; padding-bottom: 10px;'>
      <?php
      if(empty($_SESSION['username'])){
        echo "You forgot to sign in! Please go back to main page and sign in.";
      } else
        echo $_SESSION['username']; ?></h3>
    <ul id="hamburger">
      <li style='width: 50px;'><img src='menu-icon.jpg' width='50px' height='50px'></img>
        <ul style='width:120px'>
            <li id="menu-signout">Sign Out</li>
        </ul>
      </li>
    </ul>
  </div>


  <div class="containerTab" style="background-color:black">
    <div class="collapse navbar-collapse" id="navbar-collapse-main">
      <ul class='nav navbar-nav navbar-center'>
        <li><a id="startpage" href="#">Main Page</a></li>
        <li><a id="sell" href="#">Sell Rifle</a></li>
        <li><a id="forum" href="#">Forum</a></li>
      </ul>
    </div>
  </div>

  <div id="back">
    <h1 style="text-align: center">Hunting Rifles</h1>
    <div class="padding">
      <div class="container" id="list">
        <div class="row">
          <h2>Beanfield Sniper Remington Sendero SF II</h2>
        </div>
        <div class="row">
          <img src="m700.png">
        </div>
        <div class="row">
          <div id="m700des" class="collapse">With a heavy 26-inch barrel, the Sendero is built to squeeze as much
             velocity as possible out of flat-­shooting cartridges for long,accurate shots. The
             rifle is heavy—with a scope, it is going to weigh 10 pounds or more—but if you’ve
              got a short hike to your stand or don’t mind humping a beefy rig, the Sendero is
              ideal. The rigid HS Precision stock helps with accuracy. Currently it’s offered
              in 7mm Rem. Mag., .300 Win. Mag., and .300 Rem. Ultramag., though if you search
             for used guns, you might find one in the underappreciated .264 Win.</div>
          <button data-toggle="collapse" data-target="#m700des">Read Description</button>
        </div>
        <div class="row">
          <button id="buy-m700">Purchase</button>
        </div>

        <div class="row">
          <h2>Sako 85 Finnlight Bolt-Action</h2>
        </div>
        <div class="row">
          <img src="sako85.png">
        </div>
        <div class="row">
          <div id="sako85" class="collapse">The Sako Finnlight won Outdoor Life’s Editor’s
            Choice award a few years back due to its superb accuracy and reliability,
            which are not a given for rifles that have thin barrels and other weight-saving
            features. Light weight often comes at the expense of performance, but that’s not
            so with the 6-pound Finnlight. I’ve shot this rifle until it’s hot enough to fry
            an egg on its fluted barrel, but it still manages tight groups. It comes in a wide
            range of great calibers—.260 Rem., .270 WSM, 6.5x55 SE, 7mm Rem. Mag., to name a
            few—but I think it would be hard to top the .308, given the cartridge’s mild recoil,
            proven killing power, and broad selection of accurate loads.</div>
          <button data-toggle="collapse" data-target="#sako85">Read Description</button>
        </div>
        <div class="row">
          <button id="buy-sako85">Purchase</button>
        </div>

        <div class="row">
          <h2>Small-Plot Smasher Ambush 300 Blackout</h2>
        </div>
        <div class="row">
          <img src="smasher.jpg">
        </div>
        <div class="row">
          <div id="smasher" class="collapse">Hunters on small parcels of private ground need a
            rifle with the ability to put an animal down quickly. This is a scenario where a
            large-caliber AR shines. A deer that makes it to land where the hunter doesn’t
            have permission to search can be a nightmare to recover. The Ambush 300 Blackout is
            well suited for this kind of work. Most hunters will probably opt for the supersonic
            .30-caliber loads that launch bullets weighing around 115 to 125 grains at 2,200 fps
            or more. For shots out to 200 yards, these rounds are deadly, and given the moderate
             recoil and semi-automatic operation of the Ambush, fast follow-up shots are possible
             if needed. The Ambush comes with a threaded 16-inch barrel, so attaching a sound
             suppressor to lessen the muzzle blast is easy to do, should the hunter want to save
              his hearing and be less of a nuisance to whoever might live nearby. </div>
          <button data-toggle="collapse" data-target="#smasher">Read Description</button>
        </div>
        <div class="row">
          <button id="buy-smasher">Purchase</button>
        </div>

      </div>
      <form id='form-signout' method='post' action='caliber_controller.php' style='display:none'>
          <input type='hidden' name='page' value='StartPage'>
          <input type='hidden' name='command' value='SignOut'>
      </form>
    </div>
  </div>
</body>
