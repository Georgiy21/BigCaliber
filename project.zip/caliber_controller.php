<?php
if(empty($_POST['page'])){
  $display_type = "no-signin";
  include('caliber_startpage.php');
  exit();
}

session_start();

require('caliber_model.php');

if($_POST['page'] == 'StartPage'){
    $command = $_POST['command'];
    switch($command){
        case 'SignIn':
            if (!is_valid($_POST['username'], $_POST['password'])) {
              $error_msg_username = '* Invalid username';
              $error_msg_password = '* Invalid password';
              $display_type = 'signin';
              include('caliber_startpage.php');
            } else {
              $_SESSION['signedin'] = 'YES';
              $_SESSION['username'] = $_POST['username'];
              $username = $_POST['username'];
              include('caliber_startpage.php');
            }
            exit();

        case 'Join':
            if (does_exist($_POST['username'])) {
                $error_msg_username = '* The user exists.';
                $error_msg_password = '';
                $display_type = 'join';
                include('caliber_startpage.php');
            } else {
                insert_new_user($_POST['username'], $_POST['password'], $_POST['fname'], $_POST['lname'], $_POST['email'], $_POST['dr_license']);
                $display_type = 'signin';
                include('caliber_startpage.php');
            }
            exit();
        case 'Reset':
            if (!does_exist($_POST['username'])) {
                $error_msg_username = '* The user does not exist.';
                $display_type = 'reset';
                include('caliber_startpage.php');
            } else {
              if(strcmp($_POST['new_password'], $_POST['con_password']) == 0){
                reset_password($_POST['username'], $_POST['new_password']);
                $display_type = 'signin';
                include('caliber_startpage.php');
              } else {
                  $error_msg_password = '* Confirm password does not match. ';
                  $display_type = 'reset';
                  include('caliber_startpage.php');
              }
            }
            exit();
        case 'SignOut':
            session_unset();
            session_destroy();
            $display_type = 'no-signin';
            include('caliber_startpage.php');
            break;
        case 'Unsubscribe':
            unsubscribe($_POST['username']);
            $display_type = 'no-signin';
            include('caliber_startpage.php');
            break;
    }

}
else if($_POST['page'] == 'BuyRemington'){

    $command = $_POST['command'];

    switch ($command) {
        case 'SubmitForm':
              buy_rifle($_POST['fname'], $_POST['lname'], $_POST['dr_license'], $_POST['address'], $_POST['city'], $_POST['rifle']);
              $display_type = 'submit_purchase';
              include('caliber_shop.php');
              //case...
              exit();
        case 'SignOut':
              session_unset();
              session_destroy();
              $display_type = 'no-signin';
              include('caliber_startpage.php');
              break;
        default:
          echo 'Unknown command - ' . $command . '<br>';
    }
}
else if($_POST['page'] == 'BuySako'){

    $command = $_POST['command'];

    switch ($command) {
        case 'SubmitForm':
              buy_rifle($_POST['fname'], $_POST['lname'], $_POST['dr_license'], $_POST['address'], $_POST['city'], $_POST['rifle']);
              $display_type = 'submit_purchase';
              include('caliber_shop.php');
              //case...
              exit();
        case 'SignOut':
              session_unset();
              session_destroy();
              $display_type = 'no-signin';
              include('caliber_startpage.php');
              break;
        default:
          echo 'Unknown command - ' . $command . '<br>';
    }
}
else if($_POST['page'] == 'BuySmasher'){

    $command = $_POST['command'];

    switch ($command) {
        case 'SubmitForm':
              buy_rifle($_POST['fname'], $_POST['lname'], $_POST['dr_license'], $_POST['address'], $_POST['city'], $_POST['rifle']);
              $display_type = 'submit_purchase';
              include('caliber_shop.php');
              //case...
              exit();
        case 'SignOut':
              session_unset();
              session_destroy();
              $display_type = 'no-signin';
              include('caliber_startpage.php');
              break;
        default:
          echo 'Unknown command - ' . $command . '<br>';
    }
}
else if($_POST['page'] == 'SellPage'){

    $command = $_POST['command'];

    switch ($command) {
      case 'SubmitSale':
            sell_rifle($_POST['fname'], $_POST['lname'], $_POST['dr_license'], $_POST['address'], $_POST['city'], $_POST['make'], $_POST['model'], $_POST['caliber'], $_POST['sin'], $_POST['comment']);
            include('caliber_sellpage.php');
            exit();
      case 'SignOut':
            session_unset();
            session_destroy();
            $display_type = 'no-signin';
            include('caliber_startpage.php');
            break;
      default:
          echo 'Unknown command - ' . $command . '<br>';
    }
}
 ?>
