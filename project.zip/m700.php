<!DOCTYPE html>

<?php
  session_start();
?>

<html>
<head>
    <title>Big Caliber</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
    img{
      max-width: 100%;
    }
    .form-style-9{
	      max-width: 600px;
	      background: #FAFAFA;
  	    padding: 30px;
	      margin: 50px auto;
	      border-radius: 10px;
	      border: 6px solid #305A72;
    }
    #hamburger{
      position: fixed;
      top: 0;
      right: 30px;
    }
    #hamburger li, #hamburger ul {
        list-style: none;
        padding: 0;
        background-color: Gray;
        cursor:pointer;
    }
    #hamburger ul {
        border:1px solid black;
    }
    #hamburger > li {
        position: relative;
    }
    #hamburger > li > ul {
        display: none;
        position: absolute;
        top: 100%;
        right: 0;
    }
    #hamburger > li > ul > li { padding: 5px; }
    #hamburger li:hover {
        background-color: #eee;
    }
    #hamburger > li:hover > ul {
        display: block;
    }
    </style>
    <script>
        window.addEventListener('load', function() {
            document.getElementById('startpage').addEventListener('click', open_startpage);
            document.getElementById('shop').addEventListener('click', open_shop);
            document.getElementById('sell').addEventListener('click', open_sell);
            document.getElementById('forum').addEventListener('click', open_forum);
            document.getElementById('menu-signout').addEventListener('click', signout);

            <?php
                if (isset($display_type))
                    if ($display_type == 'submit_purchase')
                        echo 'submit();';
                    else
                        ;
            ?>
        });

        function open_shop(){
            window.open("caliber_shop.php", "_self");
        }
        function open_forum(){
            window.open("caliber_forumpage.php", "_self");
        }
        function open_sell(){
            window.open("caliber_sellpage.php", "_self");
        }
        function open_startpage(){
            window.open("caliber_startpage.php", "_self");
        }
        function submit(){
          alert("You successfully purchased Beanfield Sniper Remington Sendero SF II!");
        }
        function signout() {
            document.getElementById('form-signout').submit();
        }

</script>
    <script>
        $('#submitForm').click(function(){

          var url = "caliber_controller.php";
          var query = { page: "BuyRemington", command: "SubmitForm", rifle: "Beanfield Sniper Remington Sendero SF II" ,
                        fname: $('#fname').val(), lname: $('#lname').val(), dr_license: $('#dr_license').val(), address: $('#address').val(), city: $('#city').val() };

          $.post(url, query,
            function(data, status){
                alert("Data: " + data + "\nStatus: " + status);
          });
        });
    </script>
</head>
<body>
  <div class="containerTab">
    <h1 style='text-align:center; padding-top: 10px'>Big Caliber</h1>
    <h3 style='text-align:center; padding-bottom: 10px;'>
      <?php
      if(empty($_SESSION['username'])){
        echo "You forgot to sign in! Please go back to main page and sign in.";
      } else
        echo $_SESSION['username']; ?></h3>
        <ul id="hamburger">
          <li style='width: 50px;'><img src='menu-icon.jpg' width='50px' height='50px'></img>
            <ul style='width:120px'>
                <li id="menu-signout">Sign Out</li>
            </ul>
          </li>
        </ul>
  </div>

  <div class="containerTab" style="background-color:black">
    <div class="collapse navbar-collapse" id="navbar-collapse-main">
      <ul class='nav navbar-nav navbar-center'>
        <li><a id="startpage" class='active' href="#">Main Page</a></li>
        <li><a id="shop" href="#">Shop</a></li>
        <li><a id="sell" href="#">Sell Rifle</a></li>
        <li><a id="forum" href="#">Forum</a></li>
      </ul>
    </div>
  </div>

<div id="back">
  <h1 style="text-align: center">Buy Beanfield Sniper Remington Sendero SF II</h1>
  <div class="padding">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <img src="m700.png">
            <p ><b>Type Model:</b> Model 700</p>
            <p><b>Price:</b> $1502</p>
            <p><b>Caliber:</b> 7mm Remington Mag</p>
          </div>
          <div class="col-sm-6">
            <p style="text-align: center">Built on the famous Model 700™
              cylindrical action, Remington Sendero rifles are the most
              accurate we produce for over-the-counter sale. You’ll be stunned
              by the degree of precision you get straight out of the box.
              Big game won’t be so lucky. The Model 700 Sendero SF II is a
              finely tuned tack-driver created using input from serious shooters
              across America. The HS Precision stock is reinforced with aramid
              fibers and features contoured beavertail fore-end with ambidextrous
              finger grooves and palm swell. Twin front swivel studs accommodate a
              sling and a bi-pod. Full-length aluminum bedding blocks create
              accuracy-enhancing platforms for the barreled actions. The 26" heavy-contour
              barrels are fluted for rapid cooling.</p>
          </div>
          </div>
          <div class="container" id="inputform">
            <form method="post" class="form-style-9" name="myForm" action="caliber_controller.php">
                  <input type='hidden' name='page' value='BuyRemington'></input>
                  <input type='hidden' name='command' value='SubmitForm'></input>
                  <input type="hidden" name="rifle" value="Beanfield Sniper Remington Sendero SF II"></input>
                  First Name:
                  <input type="text" name="fname" id="fname" class="field-style field-split align-left" required/>
                  Last Name:
                  <input type="text" name="lname" id="lname" class="field-style field-split align-right" required/><br><br>
                  Driver's License:
                  <input type="text" name="dr_license" id="dr_license" class="field-style field-split align-none" required/><br><br>
                  Address:
                  <input type="text" name="address" id="address" class="field-style field-split align-left" required/>
                  City:
                  <input type="text" name="city" id="city" class="field-style field-split align-right" required/><br><br>
                  Credit Card Number:
                  <input type="text" name="card_num" class="field-style field-split align-none" placeholder="optional"/><br><br>
                  Expiration Date:
                  <input type="text" name="mm" class="field-style field-split align-none" placeholder="MM (optional)" maxlength="2" />  <input type="text" name="yyyy" class="field-style field-split align-none" placeholder="YYYY (optional)" maxlength="4" /><br><br>
                  Security Code:
                  <input type="text" name="s_code" class="field-style field-split align-none" placeholder="optional"/><br><br>
                  <button type="submit" value="Submit" id="submitForm">Submit</button>
            </form>
          </div>
      </div>
  </div>
  <form id='form-signout' method='post' action='caliber_controller.php' style='display:none'>
      <input type='hidden' name='page' value='StartPage'>
      <input type='hidden' name='command' value='SignOut'>
  </form>
</div>

</body>
